package com.example.instagramclone;


import android.app.Application;


import android.app.Application;

import com.Parse.Parse;
import com.Parse.ParseObject;


public class ParseApplication extends Application {

    @Override
    public void onCreate(){
        super.onCreate();
        ParseObject.registarSubclass(Post.class);
        Parse.initialize(new Parse.Configuration.Builder(this)
                .applicationId("CLSqXlYbY72YG6grkKo3xQ25zE4k1qbRJ7CoMizT")
                .clientKey("g1y5X1GejpkYB2z7KzqK6fyJ3ISQftNxVUFX9OtZ")
                .server("https://parseapi.back4app.com")
                .build()
    }

    private static class Parse {
    }
}





